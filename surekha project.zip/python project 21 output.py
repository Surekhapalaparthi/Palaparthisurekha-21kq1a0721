Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:\Users\kunda\AppData\Local\Programs\Python\Python312\python project 21.py
20
Enter name:surekha
Enter the no of persons in a family:4
Give rating on scale of 1 to 5 on room_quality:4
write a comment on dining_experience:4
Enter your rating on cleanliness:3
Enter your overall_rating:4
Enter name:varsha
Enter the no of persons in a family:4
Give rating on scale of 1 to 5 on room_quality:4
write a comment on dining_experience:good
Enter your rating on cleanliness:3
Enter your overall_rating:4
Enter name:susmi
Enter the no of persons in a family:4
Give rating on scale of 1 to 5 on room_quality:3
write a comment on dining_experience:good
Enter your rating on cleanliness:4
Enter your overall_rating:4
Enter name:vyshu
Enter the no of persons in a family:5
Give rating on scale of 1 to 5 on room_quality:3
write a comment on dining_experience:very good
Enter your rating on cleanliness:3
Enter your overall_rating:3
Enter name:hema
Enter the no of persons in a family:5
Give rating on scale of 1 to 5 on room_quality:4
write a comment on dining_experience:nice
Enter your rating on cleanliness:4
Enter your overall_rating:3
Enter name:akhila
Enter the no of persons in a family:5
Give rating on scale of 1 to 5 on room_quality:1
write a comment on dining_experience:2
Enter your rating on cleanliness:2
Enter your overall_rating:5
Enter name:raga
Enter the no of persons in a family:5
Give rating on scale of 1 to 5 on room_quality:4
write a comment on dining_experience:nice
Enter your rating on cleanliness:3
Enter your overall_rating:4
Enter name:teju
Enter the no of persons in a family:4
Give rating on scale of 1 to 5 on room_quality:4
write a comment on dining_experience:good
Enter your rating on cleanliness:5
Enter your overall_rating:4
Enter name:renu
Enter the no of persons in a family:5
Give rating on scale of 1 to 5 on room_quality:4
write a comment on dining_experience:good
Enter your rating on cleanliness:5
Enter your overall_rating:4
Enter name:loki
Enter the no of persons in a family:4
Give rating on scale of 1 to 5 on room_quality:3
write a comment on dining_experience:bad
Enter your rating on cleanliness:4
Enter your overall_rating:3
Enter name:harshith
Enter the no of persons in a family:5
Give rating on scale of 1 to 5 on room_quality:4
write a comment on dining_experience:good
Enter your rating on cleanliness:5
Enter your overall_rating:4
Enter name:raju
Enter the no of persons in a family:5
Give rating on scale of 1 to 5 on room_quality:4
write a comment on dining_experience:not bad
Enter your rating on cleanliness:5
Enter your overall_rating:5
Enter name:kumar
Enter the no of persons in a family:4
Give rating on scale of 1 to 5 on room_quality:3
write a comment on dining_experience:nice
Enter your rating on cleanliness:4
Enter your overall_rating:3
Enter name:vamsi
Enter the no of persons in a family:6
Give rating on scale of 1 to 5 on room_quality:5
write a comment on dining_experience:good
Enter your rating on cleanliness:4
Enter your overall_rating:5
Enter name:teja
Enter the no of persons in a family:3
Give rating on scale of 1 to 5 on room_quality:5
write a comment on dining_experience:5
Enter your rating on cleanliness:4
Enter your overall_rating:5
Enter name:ram
Enter the no of persons in a family:5
Give rating on scale of 1 to 5 on room_quality:4
write a comment on dining_experience:good
Enter your rating on cleanliness:3
Enter your overall_rating:4
Enter name:priya
Enter the no of persons in a family:5
Give rating on scale of 1 to 5 on room_quality:5
write a comment on dining_experience:good
Enter your rating on cleanliness:5
Enter your overall_rating:4
Enter name:kumar
Enter the no of persons in a family:6
Give rating on scale of 1 to 5 on room_quality:3
write a comment on dining_experience:good
Enter your rating on cleanliness:6
Enter your overall_rating:4
Enter name:sukumar
Enter the no of persons in a family:6
Give rating on scale of 1 to 5 on room_quality:4
write a comment on dining_experience:very bad
Enter your rating on cleanliness:1
Enter your overall_rating:2
Enter name:krishna
Enter the no of persons in a family:4
Give rating on scale of 1 to 5 on room_quality:3
write a comment on dining_experience:2
Enter your rating on cleanliness:2
Enter your overall_rating:3
        name  family  ...  cleanliness overall_rating
0    surekha       4  ...            3              4
1     varsha       4  ...            3              4
2      susmi       4  ...            4              4
3      vyshu       5  ...            3              3
4       hema       5  ...            4              3
5     akhila       5  ...            2              5
6       raga       5  ...            3              4
7       teju       4  ...            5              4
8       renu       5  ...            5              4
9       loki       4  ...            4              3
10  harshith       5  ...            5              4
11      raju       5  ...            5              5
12     kumar       4  ...            4              3
13     vamsi       6  ...            4              5
14      teja       3  ...            4              5
15       ram       5  ...            3              4
16     priya       5  ...            5              4
17     kumar       6  ...            6              4
18   sukumar       6  ...            1              2
19   krishna       4  ...            2              3

[20 rows x 6 columns]
surekha
varsha
hema
raga
teju
renu
harshith
raju
vamsi
teja
ram
priya
sukumar
susmi
vyshu
akhila
loki
kumar
kumar
krishna
12
