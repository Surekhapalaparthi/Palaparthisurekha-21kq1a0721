import pandas as pd
p=[]
def add_feedback(name,family,room_quality,dining_experience,cleanliness,overall_rating):
    feedback={
        'name':name,
        'family':family,
        'room_quality':room_quality,
        'dining_experience':dining_experience,
        'cleanliness':cleanliness,
        'overall_rating':overall_rating
    }
    p.append(feedback)
n=int(input())
for _ in range(n):
    name=input("Enter name:")
    family=int(input("Enter the no of persons in a family:"))
    room_quality=int(input("Give rating on scale of 1 to 5 on room_quality:"))
    dining_experience=input("write a comment on dining_experience:" )
    cleanliness=int(input("Enter your rating on cleanliness:")) 
    overall_rating=int(input("Enter your overall_rating:"))
    add_feedback(name,family,room_quality,dining_experience,cleanliness,overall_rating)   
'''for i in range(n):
    print(s[i])'''
df=pd.DataFrame(p)
print(df)    
for i in range(n):
    if p[i]['room_quality'] > 3:
        print(p[i]['name'])
for i in range(n):
    if p[i]['room_quality'] <= 3:
        print(p[i]['name'])
c1=0
for i in range(n):
    if p[i]['cleanliness'] > 3:
        c1+=1
print(c1)
c2=0
for i in range(n):
    if p[i]['cleanliness'] <= 3 :
        c2+=1
c3=0
for i in range(n):
    if p[i]['overall_rating'] == 1:
        c3+=1
c4=0
for i in range(n):
    if p[i]['overall_rating'] == 2:
        c4+=1
c5=0
for i in range(n):
    if p[i]['overall_rating'] == 3:
        c5+=1
c6=0
for i in range(n):
    if p[i]['overall_rating'] == 4:
        c6+=1
c7=0
for i in range(n):
    if p[i]['overall_rating'] == 5:
        c7+=1
M=input()
for i in range(n):
    if p[i]['name'] == M:
        print(p[i]['name'],p[i]['family'],p[i]['room_quality'],p[i]['dining_experience'],p[i]['cleanliness'],p[i]['overall_rating'])

    


